<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) {
    die("Unauthorized");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $folder = trim($_POST['folder']);
    $user_id = $_SESSION['user_id'];

    if (empty($folder)) {
        die("Folder name cannot be empty.");
    }

    $stmt = $conn->prepare("SELECT id FROM folders WHERE user_id = ? AND name = ?");
    $stmt->bind_param("is", $user_id, $folder);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        die("Folder already exists.");
    }

    $stmt = $conn->prepare("INSERT INTO folders (user_id, name) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, $folder);
    if ($stmt->execute()) {
        header("Location: files.php");
    } else {
        die("Error creating folder.");
    }
}
?>