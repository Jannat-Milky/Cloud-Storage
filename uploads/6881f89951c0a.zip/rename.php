<?php
session_start();
require 'db.php';

if (!isset($_SESSION['user_id'])) die("Unauthorized");

$type = $_GET['type'] ?? '';
$id = (int)($_GET['id'] ?? 0);
$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_name = trim($_POST['new_name']);

    if (empty($new_name)) {
        $error = "Name cannot be empty.";
    } elseif ($type === 'file') {
        $stmt = $conn->prepare("UPDATE files SET original_name = ? WHERE id = ? AND user_id = ?");
        $stmt->bind_param("sii", $new_name, $id, $user_id);
        $stmt->execute();
        header("Location: files.php");
        exit();
    } elseif ($type === 'folder') {
        $check = $conn->prepare("SELECT id FROM folders WHERE user_id = ? AND name = ? AND id != ?");
        $check->bind_param("isi", $user_id, $new_name, $id);
        $check->execute();
        $check->store_result();
        if ($check->num_rows > 0) {
            $error = "Folder with this name already exists.";
        } else {
            $stmt = $conn->prepare("UPDATE folders SET name = ? WHERE id = ? AND user_id = ?");
            $stmt->bind_param("sii", $new_name, $id, $user_id);
            $stmt->execute();
            header("Location: files.php");
            exit();
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head><title>Rename</title></head>
<body>
    <h2>Rename <?= htmlspecialchars($type) ?></h2>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form method="POST">
        <input type="text" name="new_name" required placeholder="New Name">
        <button type="submit">Rename</button>
    </form>
    <p><a href="files.php">Back</a></p>
</body>
</html>